import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Calendar, Clock, Target } from "lucide-react";
import { OrderData } from "./OrderForm";

interface PlanningScreenProps {
  orderData: OrderData;
  onSelectPlan: (plan: string) => void;
}

const planOptions = [
  {
    id: 'A',
    name: 'Plan A - Balanced',
    efficiency: '55%',
    startDate: 'Jan 15, 2024',
    duration: '18 days',
    otdStatus: 'green',
    otdText: 'On Track',
    description: 'Standard line configuration with optimal operator distribution'
  },
  {
    id: 'B',
    name: 'Plan B - Fast Track',
    efficiency: '52%',
    startDate: 'Jan 12, 2024',
    duration: '15 days',
    otdStatus: 'amber',
    otdText: 'Tight Schedule',
    description: 'Accelerated timeline with additional resources'
  },
  {
    id: 'C',
    name: 'Plan C - High Efficiency',
    efficiency: '58%',
    startDate: 'Jan 18, 2024',
    duration: '16 days',
    otdStatus: 'green',
    otdText: 'Comfortable',
    description: 'Optimized for maximum efficiency with extended setup time'
  }
];

const getOTDColor = (status: string) => {
  switch (status) {
    case 'green': return '#27AE60';
    case 'amber': return '#F39C12';
    case 'red': return '#C0392B';
    default: return '#27AE60';
  }
};

export function PlanningScreen({ orderData, onSelectPlan }: PlanningScreenProps) {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">OptiOps Lite — Line Balancing AI</h1>
          <p className="text-gray-600">Production Planning Options</p>
        </div>

        {/* Order Summary */}
        <Card className="p-6 shadow-lg">
          <h3 className="mb-4">Order Summary</h3>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Order ID:</span>
              <p className="font-semibold">{orderData.orderId}</p>
            </div>
            <div>
              <span className="text-gray-600">Style:</span>
              <p className="font-semibold">{orderData.style}</p>
            </div>
            <div>
              <span className="text-gray-600">SAM:</span>
              <p className="font-semibold">{orderData.sam} min</p>
            </div>
            <div>
              <span className="text-gray-600">FOB:</span>
              <p className="font-semibold">${orderData.fob}</p>
            </div>
            <div>
              <span className="text-gray-600">Quantity:</span>
              <p className="font-semibold">{orderData.quantity} pcs</p>
            </div>
            <div>
              <span className="text-gray-600">Ex-Factory:</span>
              <p className="font-semibold">{new Date(orderData.exFactoryDate).toLocaleDateString()}</p>
            </div>
          </div>
        </Card>

        {/* Planning Options */}
        <div className="space-y-4">
          <h3>Select Production Plan</h3>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {planOptions.map((plan) => (
              <Card key={plan.id} className="p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="space-y-4">
                  {/* Plan Header */}
                  <div className="border-b pb-4">
                    <h4 className="text-lg">{plan.name}</h4>
                    <p className="text-sm text-gray-600">{plan.description}</p>
                  </div>

                  {/* Key Metrics */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Target className="h-5 w-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">Efficiency: </span>
                        <span className="font-semibold" style={{ color: '#27AE60' }}>
                          {plan.efficiency}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Calendar className="h-5 w-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">Start Date: </span>
                        <span className="font-semibold">{plan.startDate}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Clock className="h-5 w-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-600">Duration: </span>
                        <span className="font-semibold">{plan.duration}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: getOTDColor(plan.otdStatus) }}
                      ></div>
                      <div>
                        <span className="text-sm text-gray-600">OTD Status: </span>
                        <span 
                          className="font-semibold"
                          style={{ color: getOTDColor(plan.otdStatus) }}
                        >
                          {plan.otdText}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Select Button */}
                  <Button
                    onClick={() => onSelectPlan(plan.id)}
                    className="w-full mt-4"
                    style={{ backgroundColor: '#27AE60' }}
                  >
                    Select this Plan
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* AI Recommendation */}
        <Card className="p-6 shadow-lg border-l-4" style={{ borderLeftColor: '#27AE60' }}>
          <div className="flex items-start gap-4">
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: '#27AE60' }}>
              <span className="text-white text-sm">AI</span>
            </div>
            <div>
              <h4>AI Recommendation</h4>
              <p className="text-sm text-gray-600 mt-1">
                Based on your order requirements and current capacity, <strong>Plan C</strong> offers 
                the best balance of efficiency and delivery reliability. The higher efficiency will 
                provide better margins while maintaining comfortable delivery timelines.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}