import { useState } from 'react';
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Upload } from "lucide-react";

interface OrderFormProps {
  onGeneratePlans: (orderData: OrderData, hasFile: boolean) => void;
}

export interface OrderData {
  orderId: string;
  style: string;
  sam: string;
  fob: string;
  quantity: string;
  exFactoryDate: string;
}

export function OrderForm({ onGeneratePlans }: OrderFormProps) {
  const [orderData, setOrderData] = useState<OrderData>({
    orderId: '',
    style: '',
    sam: '',
    fob: '',
    quantity: '',
    exFactoryDate: ''
  });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleInputChange = (field: keyof OrderData, value: string) => {
    setOrderData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleSubmit = () => {
    onGeneratePlans(orderData, !!uploadedFile);
  };

  const isFormValid = orderData.orderId && orderData.style && orderData.sam && 
                     orderData.fob && orderData.quantity && orderData.exFactoryDate;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">OptiOps Lite — Line Balancing AI</h1>
          <p className="text-gray-600">New Production Order</p>
        </div>

        <Card className="p-8 shadow-lg">
          <h3 className="mb-6">Order Details</h3>
          
          <div className="space-y-6">
            {/* Order ID and Style */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="orderId">Order ID</Label>
                <Input
                  id="orderId"
                  placeholder="e.g. ORD-2024-001"
                  value={orderData.orderId}
                  onChange={(e) => handleInputChange('orderId', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="style">Style</Label>
                <Input
                  id="style"
                  placeholder="e.g. T-Shirt Basic"
                  value={orderData.style}
                  onChange={(e) => handleInputChange('style', e.target.value)}
                />
              </div>
            </div>

            {/* SAM and FOB */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="sam">SAM (min)</Label>
                <Input
                  id="sam"
                  type="number"
                  step="0.01"
                  placeholder="e.g. 12.50"
                  value={orderData.sam}
                  onChange={(e) => handleInputChange('sam', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fob">FOB ($/unit)</Label>
                <Input
                  id="fob"
                  type="number"
                  step="0.01"
                  placeholder="e.g. 15.75"
                  value={orderData.fob}
                  onChange={(e) => handleInputChange('fob', e.target.value)}
                />
              </div>
            </div>

            {/* Quantity and Ex-Factory Date */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity (pcs)</Label>
                <Input
                  id="quantity"
                  type="number"
                  placeholder="e.g. 5000"
                  value={orderData.quantity}
                  onChange={(e) => handleInputChange('quantity', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="exFactoryDate">Ex-Factory Date</Label>
                <Input
                  id="exFactoryDate"
                  type="date"
                  value={orderData.exFactoryDate}
                  onChange={(e) => handleInputChange('exFactoryDate', e.target.value)}
                />
              </div>
            </div>

            {/* File Upload */}
            <div className="space-y-2">
              <Label htmlFor="obFile">Upload OB file (Optional)</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 mb-2">
                  Upload Operations Bulletin (.csv/.xlsx)
                </p>
                <input
                  id="obFile"
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('obFile')?.click()}
                >
                  Choose File
                </Button>
                {uploadedFile && (
                  <p className="text-sm text-green-600 mt-2">
                    ✓ {uploadedFile.name} uploaded
                  </p>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <Button
                onClick={handleSubmit}
                disabled={!isFormValid}
                className="w-full py-3"
                style={{ backgroundColor: isFormValid ? '#27AE60' : undefined }}
              >
                Generate Plans
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}