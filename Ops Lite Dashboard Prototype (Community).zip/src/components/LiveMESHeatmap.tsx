import { Card } from "./ui/card";

interface LiveMESHeatmapProps {
  onTileClick: (opId: string) => void;
  efficiency?: number;
}

const operationTiles = [
  { id: 'OP01', status: 'stable' },
  { id: 'OP02', status: 'stable' },
  { id: 'OP03', status: 'at-risk' },
  { id: 'OP04', status: 'bottleneck' },
  { id: 'OP05', status: 'stable' },
  { id: 'OP06', status: 'stable' },
  { id: 'OP07', status: 'at-risk' },
  { id: 'OP08', status: 'stable' },
  { id: 'OP09', status: 'stable' },
  { id: 'OP10', status: 'at-risk' },
  { id: 'OP11', status: 'stable' },
  { id: 'OP12', status: 'stable' },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'stable': return '#27AE60';
    case 'at-risk': return '#F39C12';
    case 'bottleneck': return '#C0392B';
    default: return '#27AE60';
  }
};

const getStatusText = (status: string) => {
  switch (status) {
    case 'stable': return 'Stable';
    case 'at-risk': return 'At Risk';
    case 'bottleneck': return 'Bottleneck';
    default: return 'Stable';
  }
};

export function LiveMESHeatmap({ onTileClick, efficiency = 56 }: LiveMESHeatmapProps) {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">OptiOps Lite — Line Balancing AI</h1>
          <p className="text-gray-600">Live MES Heatmap</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
          {/* Operation Grid */}
          <div className="lg:col-span-3">
            <Card className="p-6 shadow-lg h-full">
              <h3 className="mb-6">Production Line Status</h3>
              <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
                {operationTiles.map((tile) => (
                  <div
                    key={tile.id}
                    onClick={() => onTileClick(tile.id)}
                    className="aspect-square p-4 rounded-lg cursor-pointer transition-all hover:scale-105 hover:shadow-lg flex flex-col items-center justify-center"
                    style={{ backgroundColor: getStatusColor(tile.status) }}
                  >
                    <div className="text-white text-center">
                      <p className="text-lg font-semibold">{tile.id}</p>
                      <p className="text-sm opacity-90">{getStatusText(tile.status)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Live Line Health Sidebar */}
          <div className="space-y-4">
            <Card className="p-4 shadow-lg">
              <h4 className="mb-4">Live Line Health</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Overall Efficiency</span>
                  <span className="font-semibold" style={{ color: '#27AE60' }}>{efficiency}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Current Takt</span>
                  <span className="font-semibold">1.20 min</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Active Bottlenecks</span>
                  <span className="font-semibold text-red-600">1</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">At Risk Operations</span>
                  <span className="font-semibold" style={{ color: '#F39C12' }}>3</span>
                </div>
              </div>
            </Card>

            <Card className="p-4 shadow-lg">
              <h4 className="mb-4">Line Status</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#27AE60' }}></div>
                  <span className="text-sm">8 Stable</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#F39C12' }}></div>
                  <span className="text-sm">3 At Risk</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#C0392B' }}></div>
                  <span className="text-sm">1 Bottleneck</span>
                </div>
              </div>
            </Card>

            <Card className="p-4 shadow-lg">
              <h4 className="mb-4">Quick Actions</h4>
              <div className="space-y-2">
                <button className="w-full text-left p-2 text-sm hover:bg-gray-100 rounded">
                  View Line Balance
                </button>
                <button className="w-full text-left p-2 text-sm hover:bg-gray-100 rounded">
                  Export Report
                </button>
                <button className="w-full text-left p-2 text-sm hover:bg-gray-100 rounded">
                  Alert Settings
                </button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}