import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Plus } from "lucide-react";

interface HomeScreenProps {
  onNewOrder: () => void;
}

export function HomeScreen({ onNewOrder }: HomeScreenProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="max-w-2xl w-full text-center space-y-8">
        {/* Logo/Title */}
        <div className="space-y-4">
          <h1 className="text-5xl mb-4">OptiOps Lite</h1>
          <p className="text-xl text-gray-600">Line Balancing AI</p>
          <p className="text-gray-500">Optimize your production line efficiency with AI-powered insights</p>
        </div>

        {/* Main Action Card */}
        <Card className="p-8 shadow-lg max-w-md mx-auto">
          <div className="space-y-6">
            <div className="w-16 h-16 mx-auto rounded-full flex items-center justify-center" style={{ backgroundColor: '#27AE60' }}>
              <Plus className="h-8 w-8 text-white" />
            </div>
            <div className="space-y-2">
              <h3>Start New Production Order</h3>
              <p className="text-sm text-gray-600">
                Create a new order and generate optimized production plans
              </p>
            </div>
            <Button 
              onClick={onNewOrder}
              className="w-full py-3"
              style={{ backgroundColor: '#27AE60' }}
            >
              + New Order
            </Button>
          </div>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto pt-8">
          <div className="text-center">
            <p className="text-2xl" style={{ color: '#27AE60' }}>98%</p>
            <p className="text-sm text-gray-600">On-Time Delivery</p>
          </div>
          <div className="text-center">
            <p className="text-2xl" style={{ color: '#27AE60' }}>15%</p>
            <p className="text-sm text-gray-600">Avg Efficiency Gain</p>
          </div>
          <div className="text-center">
            <p className="text-2xl" style={{ color: '#27AE60' }}>2.3min</p>
            <p className="text-sm text-gray-600">Avg Cycle Reduction</p>
          </div>
        </div>
      </div>
    </div>
  );
}