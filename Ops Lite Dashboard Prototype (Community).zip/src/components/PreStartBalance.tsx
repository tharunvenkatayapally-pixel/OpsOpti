import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, ReferenceLine } from 'recharts';

interface PreStartBalanceProps {
  efficiency: number;
  onBalanceClick: () => void;
}

const operatorData = [
  { id: 'OP01', name: 'Prep Station', operator: 'Sarah M.', estCycle: '0.95 min', smv: '0.85', qaCritical: 'Yes' },
  { id: 'OP02', name: 'Cut & Shape', operator: 'Mike R.', estCycle: '1.10 min', smv: '1.05', qaCritical: 'No' },
  { id: 'OP03', name: 'Assembly 1', operator: 'Lisa K.', estCycle: '1.25 min', smv: '1.20', qaCritical: 'Yes' },
  { id: 'OP04', name: 'Assembly 2', operator: 'John D.', estCycle: '1.55 min', smv: '1.45', qaCritical: 'No' },
  { id: 'OP05', name: 'QC Check', operator: 'Amy T.', estCycle: '0.85 min', smv: '0.80', qaCritical: 'Yes' },
];

const chartData = [
  { operation: 'OP01', cycleTime: 0.95, takt: 1.20 },
  { operation: 'OP02', cycleTime: 1.10, takt: 1.20 },
  { operation: 'OP03', cycleTime: 1.25, takt: 1.20 },
  { operation: 'OP04', cycleTime: 1.55, takt: 1.20 },
  { operation: 'OP05', cycleTime: 0.85, takt: 1.20 },
];

export function PreStartBalance({ efficiency, onBalanceClick }: PreStartBalanceProps) {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">OptiOps Lite — Line Balancing AI</h1>
          <p className="text-gray-600">Pre-Start Balance Analysis</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 shadow-lg">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Efficiency</p>
              <p className="text-3xl" style={{ color: '#27AE60' }}>{efficiency}%</p>
            </div>
          </Card>
          <Card className="p-6 shadow-lg">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Takt Time</p>
              <p className="text-3xl">1.20 min</p>
            </div>
          </Card>
          <Card className="p-6 shadow-lg">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Balance Loss</p>
              <p className="text-3xl text-orange-500">0.81 min</p>
            </div>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Operator Assignment Table */}
          <Card className="p-6 shadow-lg">
            <h3 className="mb-4">Operator Assignment</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Op ID</TableHead>
                  <TableHead>Op Name</TableHead>
                  <TableHead>Operator</TableHead>
                  <TableHead>Est Cycle</TableHead>
                  <TableHead>SMV</TableHead>
                  <TableHead>QA Critical</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {operatorData.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell className="font-medium">{row.id}</TableCell>
                    <TableCell>{row.name}</TableCell>
                    <TableCell>{row.operator}</TableCell>
                    <TableCell>{row.estCycle}</TableCell>
                    <TableCell>{row.smv}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        row.qaCritical === 'Yes' 
                          ? 'bg-red-100 text-red-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {row.qaCritical}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Cycle Time Chart */}
          <Card className="p-6 shadow-lg">
            <h3 className="mb-4">Cycle Time vs Takt Time</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="operation" />
                  <YAxis domain={[0, 2]} />
                  <ReferenceLine y={1.20} stroke="#F39C12" strokeDasharray="5 5" strokeWidth={2} />
                  <Bar 
                    dataKey="cycleTime" 
                    fill={(entry: any) => entry.cycleTime > 1.20 ? '#C0392B' : '#27AE60'} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Orange line shows Takt Time (1.20 min)
            </p>
          </Card>
        </div>

        {/* Balance Button */}
        <div className="flex justify-center">
          <Button 
            onClick={onBalanceClick}
            className="px-8 py-3 text-lg"
            style={{ backgroundColor: '#27AE60' }}
          >
            Balance This Line
          </Button>
        </div>
      </div>
    </div>
  );
}