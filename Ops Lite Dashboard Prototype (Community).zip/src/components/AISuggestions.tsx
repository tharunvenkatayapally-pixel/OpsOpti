import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { X } from "lucide-react";

interface AISuggestionsProps {
  onClose: () => void;
  onTrialAccept: () => void;
}

const suggestions = [
  {
    id: 1,
    title: "Helper Injection at OP04",
    description: "Add a helper operator to assist with complex assembly tasks",
    efficiencyGain: "+2.5%",
    newLineEfficiency: "58.5%",
    cycleChange: "1.55 → 1.35 min",
    risks: ["Space constraints", "Additional labor cost"],
    risk: "Low",
    action: "Trial 30 min",
    actionType: "trial"
  },
  {
    id: 2,
    title: "Operator Swap Trial",
    description: "Move experienced operator from OP01 to OP04 bottleneck",
    efficiencyGain: "+1.8%",
    newLineEfficiency: "56.8%",
    cycleChange: "1.55 → 1.28 min",
    risks: ["Collar operation slowdown", "QC recheck required"],
    risk: "Medium",
    action: "Trial 30 min",
    actionType: "trial"
  },
  {
    id: 3,
    title: "Parallelize OP18",
    description: "Split operation into two parallel workstations",
    efficiencyGain: "+3.0%",
    newLineEfficiency: "59.5%",
    cycleChange: "1.55 → 1.20 min",
    risks: ["Extra machine required", "Operator training needed"],
    risk: "High",
    action: "Plan Change",
    actionType: "plan"
  }
];

const getRiskColor = (risk: string) => {
  switch (risk) {
    case 'Low': return '#27AE60';
    case 'Medium': return '#F39C12';
    case 'High': return '#C0392B';
    default: return '#27AE60';
  }
};

export function AISuggestions({ onClose, onTrialAccept }: AISuggestionsProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b flex items-center justify-between">
          <div>
            <h2 className="text-2xl">AI Optimization Suggestions</h2>
            <p className="text-gray-600">OP04 Bottleneck Analysis</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="hover:bg-gray-100"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Suggestions */}
        <div className="p-6 space-y-4">
          {suggestions.map((suggestion) => (
            <Card key={suggestion.id} className="p-6 shadow-lg border-l-4" style={{
              borderLeftColor: getRiskColor(suggestion.risk)
            }}>
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold mb-2">{suggestion.title}</h4>
                    <p className="text-sm text-gray-600 mb-3">{suggestion.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                      <div>
                        <span className="text-gray-600">Efficiency Gain: </span>
                        <span className="font-semibold" style={{ color: '#27AE60' }}>
                          {suggestion.efficiencyGain}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-600">New Line Efficiency: </span>
                        <span className="font-semibold" style={{ color: '#27AE60' }}>
                          {suggestion.newLineEfficiency}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-600">Cycle Time: </span>
                        <span className="font-semibold">{suggestion.cycleChange}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Risk Level: </span>
                        <span 
                          className="font-semibold"
                          style={{ color: getRiskColor(suggestion.risk) }}
                        >
                          {suggestion.risk}
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-gray-600 text-sm">Key Risks: </span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {suggestion.risks.map((risk, index) => (
                          <span 
                            key={index}
                            className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded"
                          >
                            {risk}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <Button
                    onClick={suggestion.actionType === 'trial' ? onTrialAccept : undefined}
                    className={`ml-4 px-6 ${
                      suggestion.actionType === 'trial'
                        ? 'bg-blue-600 hover:bg-blue-700'
                        : 'bg-gray-600 hover:bg-gray-700'
                    }`}
                  >
                    {suggestion.action}
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-gray-50">
          <p className="text-sm text-gray-600">
            AI suggestions are based on historical data and current line conditions. 
            Monitor results closely during trial periods.
          </p>
        </div>
      </div>
    </div>
  );
}