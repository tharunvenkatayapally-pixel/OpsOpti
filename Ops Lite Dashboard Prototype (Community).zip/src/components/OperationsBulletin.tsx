import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, ReferenceLine } from 'recharts';

interface OperationsBulletinProps {
  hasUploadedFile: boolean;
  selectedPlan: string;
  onStartProduction: () => void;
}

const uploadedOperatorData = [
  { id: 'OP01', name: 'Front Panel Prep', operator: 'Maria G.', estCycle: '0.92 min', smv: '0.88', qaCritical: 'Yes' },
  { id: 'OP02', name: 'Side Seam Cut', operator: 'David L.', estCycle: '1.05 min', smv: '1.02', qaCritical: 'No' },
  { id: 'OP03', name: 'Shoulder Join', operator: 'Rita K.', estCycle: '1.18 min', smv: '1.15', qaCritical: 'Yes' },
  { id: 'OP04', name: 'Sleeve Attach', operator: 'James W.', estCycle: '1.48 min', smv: '1.42', qaCritical: 'No' },
  { id: 'OP05', name: 'Final QC', operator: 'Susan T.', estCycle: '0.88 min', smv: '0.82', qaCritical: 'Yes' },
  { id: 'OP06', name: 'Collar Set', operator: 'Ahmed R.', estCycle: '1.32 min', smv: '1.28', qaCritical: 'Yes' },
  { id: 'OP07', name: 'Hem Finish', operator: 'Lisa P.', estCycle: '0.95 min', smv: '0.92', qaCritical: 'No' },
];

const sampleOperatorData = [
  { id: 'OP01', name: 'Prep Station', operator: 'Sarah M.', estCycle: '0.95 min', smv: '0.85', qaCritical: 'Yes' },
  { id: 'OP02', name: 'Cut & Shape', operator: 'Mike R.', estCycle: '1.10 min', smv: '1.05', qaCritical: 'No' },
  { id: 'OP03', name: 'Assembly 1', operator: 'Lisa K.', estCycle: '1.25 min', smv: '1.20', qaCritical: 'Yes' },
  { id: 'OP04', name: 'Assembly 2', operator: 'John D.', estCycle: '1.55 min', smv: '1.45', qaCritical: 'No' },
  { id: 'OP05', name: 'QC Check', operator: 'Amy T.', estCycle: '0.85 min', smv: '0.80', qaCritical: 'Yes' },
];

const getChartData = (hasFile: boolean) => {
  if (hasFile) {
    return [
      { operation: 'OP01', cycleTime: 0.92, takt: 1.20 },
      { operation: 'OP02', cycleTime: 1.05, takt: 1.20 },
      { operation: 'OP03', cycleTime: 1.18, takt: 1.20 },
      { operation: 'OP04', cycleTime: 1.48, takt: 1.20 },
      { operation: 'OP05', cycleTime: 0.88, takt: 1.20 },
      { operation: 'OP06', cycleTime: 1.32, takt: 1.20 },
      { operation: 'OP07', cycleTime: 0.95, takt: 1.20 },
    ];
  } else {
    return [
      { operation: 'OP01', cycleTime: 0.95, takt: 1.20 },
      { operation: 'OP02', cycleTime: 1.10, takt: 1.20 },
      { operation: 'OP03', cycleTime: 1.25, takt: 1.20 },
      { operation: 'OP04', cycleTime: 1.55, takt: 1.20 },
      { operation: 'OP05', cycleTime: 0.85, takt: 1.20 },
    ];
  }
};

const getPlanEfficiency = (plan: string) => {
  switch (plan) {
    case 'A': return '55';
    case 'B': return '52';
    case 'C': return '58';
    default: return '55';
  }
};

export function OperationsBulletin({ hasUploadedFile, selectedPlan, onStartProduction }: OperationsBulletinProps) {
  const operatorData = hasUploadedFile ? uploadedOperatorData : sampleOperatorData;
  const chartData = getChartData(hasUploadedFile);
  const efficiency = getPlanEfficiency(selectedPlan);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">OptiOps Lite — Line Balancing AI</h1>
          <p className="text-gray-600">
            Operations Bulletin - Plan {selectedPlan}
            {hasUploadedFile && ' (From Uploaded File)'}
          </p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 shadow-lg">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Efficiency</p>
              <p className="text-3xl" style={{ color: '#27AE60' }}>{efficiency}%</p>
            </div>
          </Card>
          <Card className="p-6 shadow-lg">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Takt Time</p>
              <p className="text-3xl">1.20 min</p>
            </div>
          </Card>
          <Card className="p-6 shadow-lg">
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Balance Loss</p>
              <p className="text-3xl text-orange-500">
                {hasUploadedFile ? '0.74' : '0.81'} min
              </p>
            </div>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Operator Assignment Table */}
          <Card className="p-6 shadow-lg">
            <h3 className="mb-4">
              Operator Assignment
              {hasUploadedFile && (
                <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                  From Upload
                </span>
              )}
            </h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Op ID</TableHead>
                  <TableHead>Op Name</TableHead>
                  <TableHead>Operator</TableHead>
                  <TableHead>Est Cycle</TableHead>
                  <TableHead>SMV</TableHead>
                  <TableHead>QA Critical</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {operatorData.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell className="font-medium">{row.id}</TableCell>
                    <TableCell>{row.name}</TableCell>
                    <TableCell>{row.operator}</TableCell>
                    <TableCell>{row.estCycle}</TableCell>
                    <TableCell>{row.smv}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        row.qaCritical === 'Yes' 
                          ? 'bg-red-100 text-red-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {row.qaCritical}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Cycle Time Chart */}
          <Card className="p-6 shadow-lg">
            <h3 className="mb-4">Cycle Time vs Takt Time</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="operation" />
                  <YAxis domain={[0, 2]} />
                  <ReferenceLine y={1.20} stroke="#F39C12" strokeDasharray="5 5" strokeWidth={2} />
                  <Bar 
                    dataKey="cycleTime" 
                    fill="#27AE60"
                    shape={(props: any) => {
                      const { x, y, width, height, payload } = props;
                      const fillColor = payload.cycleTime > 1.20 ? '#C0392B' : '#27AE60';
                      return <rect x={x} y={y} width={width} height={height} fill={fillColor} />;
                    }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Orange line shows Takt Time (1.20 min)
            </p>
          </Card>
        </div>

        {/* Plan Summary */}
        <Card className="p-6 shadow-lg">
          <h3 className="mb-4">Plan {selectedPlan} Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Total Operations:</span>
              <p className="font-semibold">{operatorData.length}</p>
            </div>
            <div>
              <span className="text-gray-600">Critical QC Points:</span>
              <p className="font-semibold">
                {operatorData.filter(op => op.qaCritical === 'Yes').length}
              </p>
            </div>
            <div>
              <span className="text-gray-600">Bottleneck Operations:</span>
              <p className="font-semibold">1</p>
            </div>
            <div>
              <span className="text-gray-600">Line Setup Time:</span>
              <p className="font-semibold">2.5 hours</p>
            </div>
          </div>
        </Card>

        {/* Start Production Button */}
        <div className="flex justify-center">
          <Button 
            onClick={onStartProduction}
            className="px-8 py-3 text-lg"
            style={{ backgroundColor: '#27AE60' }}
          >
            Start Production
          </Button>
        </div>
      </div>
    </div>
  );
}