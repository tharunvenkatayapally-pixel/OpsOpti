import { useState } from 'react';
import { HomeScreen } from './components/HomeScreen';
import { OrderForm, OrderData } from './components/OrderForm';
import { PlanningScreen } from './components/PlanningScreen';
import { OperationsBulletin } from './components/OperationsBulletin';
import { LiveMESHeatmap } from './components/LiveMESHeatmap';
import { AISuggestions } from './components/AISuggestions';

type Screen = 'home' | 'order-form' | 'planning' | 'operations-bulletin' | 'heatmap';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [orderData, setOrderData] = useState<OrderData>({
    orderId: '',
    style: '',
    sam: '',
    fob: '',
    quantity: '',
    exFactoryDate: ''
  });
  const [hasUploadedFile, setHasUploadedFile] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('');
  const [currentEfficiency, setCurrentEfficiency] = useState(56);

  const handleNewOrder = () => {
    setCurrentScreen('order-form');
  };

  const handleGeneratePlans = (data: OrderData, hasFile: boolean) => {
    setOrderData(data);
    setHasUploadedFile(hasFile);
    setCurrentScreen('planning');
  };

  const handleSelectPlan = (plan: string) => {
    setSelectedPlan(plan);
    // Set efficiency based on plan
    const planEfficiencies = { 'A': 55, 'B': 52, 'C': 58 };
    setCurrentEfficiency(planEfficiencies[plan as keyof typeof planEfficiencies] || 56);
    setCurrentScreen('operations-bulletin');
  };

  const handleStartProduction = () => {
    setCurrentScreen('heatmap');
  };

  const handleTileClick = (opId: string) => {
    if (opId === 'OP04') {
      setShowSuggestions(true);
    }
  };

  const handleTrialAccept = () => {
    // Update efficiency based on the first suggestion (+2.5% improvement)
    // But ensure it never exceeds 60%
    const newEfficiency = Math.min(currentEfficiency + 2.5, 60);
    setCurrentEfficiency(Math.round(newEfficiency * 10) / 10);
    setShowSuggestions(false);
  };

  const handleCloseSuggestions = () => {
    setShowSuggestions(false);
  };

  return (
    <div className="min-h-screen">
      {currentScreen === 'home' && (
        <HomeScreen onNewOrder={handleNewOrder} />
      )}
      
      {currentScreen === 'order-form' && (
        <OrderForm onGeneratePlans={handleGeneratePlans} />
      )}

      {currentScreen === 'planning' && (
        <PlanningScreen 
          orderData={orderData}
          onSelectPlan={handleSelectPlan}
        />
      )}

      {currentScreen === 'operations-bulletin' && (
        <OperationsBulletin
          hasUploadedFile={hasUploadedFile}
          selectedPlan={selectedPlan}
          onStartProduction={handleStartProduction}
        />
      )}

      {currentScreen === 'heatmap' && (
        <LiveMESHeatmap 
          onTileClick={handleTileClick}
          efficiency={currentEfficiency}
        />
      )}

      {showSuggestions && (
        <AISuggestions
          onClose={handleCloseSuggestions}
          onTrialAccept={handleTrialAccept}
        />
      )}
    </div>
  );
}