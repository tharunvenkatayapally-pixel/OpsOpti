
  # Ops Lite Dashboard Prototype (Community)

  This is a code bundle for Ops Lite Dashboard Prototype (Community). The original project is available at https://www.figma.com/design/u6ZKwB04ZqeaNWJxisHf9T/Ops-Lite-Dashboard-Prototype--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  